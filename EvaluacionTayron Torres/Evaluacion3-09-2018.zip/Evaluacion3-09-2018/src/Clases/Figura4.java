/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author ESTUDIANTE
 */
public abstract class Figura4 implements EjecutaFigura4 {
    protected String NomFigura;
    protected double area;
    protected double perim;

    public String obtenerNomFigura() {
        return NomFigura;
    }

    public void establecerNomFigura(String NomFigura) {
        this.NomFigura = NomFigura;
    }

    public double obtenerArea() {
        return area;
    }


    public double obtenerPerim() {
        return perim;
    }

   public abstract void calcularArea();
   
   public abstract void calcularPerim();
    
}
