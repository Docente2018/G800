/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author ESTUDIANTE
 */
public class Circulo4 extends Figura4 {
    private double radioCirc;

    public Circulo4() {
    }

    
    
    public void establecerRadioCirc(double radioCirc) {
        this.radioCirc = radioCirc;
    }

    
    
    @Override
    public void calcularArea() {
      this.area=Math.PI*(this.radioCirc*this.radioCirc);
    }

    @Override
    public void calcularPerim() {
       this.perim=(2*Math.PI)*this.radioCirc;
    }

    @Override
    public void ejecutarFigura() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
