/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author ESTUDIANTE
 */
public class Rectangulo4 extends Figura4 {
    private double baseRecta;
    private double alturaRecta;

    public Rectangulo4() {
    }

    
    
    public void establecerBaseRecta(double baseRecta) {
        this.baseRecta = baseRecta;
    }

    public void establecerAlturaRecta(double alturaRecta) {
        this.alturaRecta = alturaRecta;
    }

    @Override
    public void calcularArea() {
       this.area=this.baseRecta*this.alturaRecta;
    }

    @Override
    public void calcularPerim() {
        this.perim=2*(this.baseRecta+this.alturaRecta);
    }

    @Override
    public void ejecutarFigura() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
