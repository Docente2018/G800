/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author ESTUDIANTE
 */
public class Cuadrado4 extends Figura4 {
    private double ladaCuad;

    public Cuadrado4() {
    }

    
    public void establecerLadaCuad(double ladaCuad) {
        this.ladaCuad = ladaCuad;
    }

    @Override
    public void calcularArea() {
       this.area=this.ladaCuad*this.ladaCuad;
    }

    @Override
    public void calcularPerim() {
      this.perim=this.ladaCuad*4;
    }

    @Override
    public void ejecutarFigura() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
