/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author ESTUDIANTE
 */
public class Triangulo4 extends Figura4 {
    private double baseTria;
    private double alturaTria;
    private double ladoA;
    private double ladoB;
    private double ladoC;

    public Triangulo4() {
    }

 
    public void establecerBaseTria(double baseTria) {
        this.baseTria = baseTria;
    }

   

    public void establecerAlturaTria(double alturaTria) {
        this.alturaTria = alturaTria;
    }

   

    public void establecerLadoA(double ladoA) {
        this.ladoA = ladoA;
    }

   

    public void establecerLadoB(double ladoB) {
        this.ladoB = ladoB;
    }

  

    public void establecerLadoC(double ladoC) {
        this.ladoC = ladoC;
    }
    
    
    
    @Override
    public void calcularArea() {
       this.area= (this.baseTria*this.area)/2;
    }

    @Override
    public void calcularPerim() {
       this.perim=(this.ladoA+this.ladoB+this.ladoC); 
    }

    @Override
    public void ejecutarFigura() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
