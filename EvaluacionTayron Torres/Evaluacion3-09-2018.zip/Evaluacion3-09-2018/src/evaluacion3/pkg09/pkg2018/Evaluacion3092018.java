/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package evaluacion3.pkg09.pkg2018;

import Clases.Circulo4;
import Clases.Cuadrado4;
import Clases.Rectangulo4;
import Clases.Triangulo4;
import java.util.Scanner;

/**
 *
 * @author ESTUDIANTE
 */
public class Evaluacion3092018 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scan=new Scanner(System.in);
        Triangulo4 triangulo=new Triangulo4();
        Cuadrado4 cuadrado=new Cuadrado4();
        Circulo4  circulo=new Circulo4();
        Rectangulo4 rectangulo=new Rectangulo4();
        int opcion=0;
        do {
        System.out.println("AREAS Y PERIMETROS DE \n FIGURAS GEOMETRICAS");
        System.out.println("____________________________________________");
        System.out.println("1 . TRIANGULO \n2 . CUADRADO\n3 . RECTANGULO\n4 . CIRCULO\n5 . FIN");
        System.out.println("____________________________________________"); 
        opcion=scan.nextInt();
        switch(opcion){
               case 1:
                   System.out.println("Ingrese del nombre del triangulo");
                   triangulo.establecerNomFigura(scan.next());
                   System.out.println("Ingrese altura del triangulo");
                   triangulo.establecerAlturaTria(scan.nextDouble());
                    System.out.println("Ingrese base del triangulo");
                   triangulo.establecerBaseTria(scan.nextDouble());
                    System.out.println("Ingrese LadoA del triangulo");
                   triangulo.establecerLadoA(scan.nextDouble());
                    System.out.println("Ingrese LadoB del triangulo");
                   triangulo.establecerLadoB(scan.nextDouble());
                    System.out.println("Ingrese LadoB del triangulo");
                    triangulo.establecerLadoC(scan.nextDouble());
                    triangulo.calcularArea();
                    triangulo.calcularPerim();
                    System.out.println("El area del "+triangulo.obtenerNomFigura()+" es :"+triangulo.obtenerArea());
                    System.out.println("El perimetro del "+triangulo.obtenerNomFigura()+" es :"+triangulo.obtenerPerim());
                  break;
               case 2:
                   System.out.println("Ingrese del nombre del cuadrado");
                   cuadrado.establecerNomFigura(scan.next());
                   System.out.println("Ingrese Un lado Del cuadrado");
                   cuadrado.establecerLadaCuad(scan.nextDouble());
                   cuadrado.calcularArea();
                   cuadrado.calcularPerim();
                   System.out.println("El area del "+cuadrado.obtenerNomFigura()+" es :"+cuadrado.obtenerArea());
                   System.out.println("El perimetro del "+cuadrado.obtenerNomFigura()+" es :"+cuadrado.obtenerPerim());
                break;    
               case 3:
                   System.out.println("Ingrese del nombre del rectangulo");
                   rectangulo.establecerNomFigura(scan.next());
                   System.out.println("Ingrese la Altura del rectangulo");
                   rectangulo.establecerAlturaRecta(scan.nextDouble());
                   System.out.println("Ingrese la Base del rectangulo");
                   rectangulo.establecerBaseRecta(scan.nextDouble());
                   System.out.println("El area del "+rectangulo.obtenerNomFigura()+" es :"+rectangulo.obtenerArea());
                   System.out.println("El perimetro del "+rectangulo.obtenerNomFigura()+" es :"+rectangulo.obtenerPerim());
                break;
               case 4:
                   System.out.println("Ingrese del nombre del circulo");
                   circulo.establecerNomFigura(scan.next());
                   System.out.println("Ingrese el radio del circulo");
                   circulo.establecerRadioCirc(scan.nextDouble());
                   System.out.println("El area del "+circulo.obtenerNomFigura()+" es :"+circulo.obtenerArea());
                   System.out.println("El perimetro del "+circulo.obtenerNomFigura()+" es :"+circulo.obtenerPerim());
                break;
              
        }
        } while (opcion!=5);
        
       
        
    }
    
}
