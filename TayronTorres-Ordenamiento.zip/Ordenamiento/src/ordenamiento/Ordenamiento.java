/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ordenamiento;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author ESTUDIANTE
 */
public class Ordenamiento {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       //Clase utilizada para la obtencion de datos 
       Scanner scanner=new Scanner(System.in);
        //Clase  para generar numeros al azar
       Random r = new Random();
       System.out.println("Ingrese el numero de lista");
       //Se obtiene el tamaño de la matriz a llenar
       int tamano=scanner.nextInt();
         System.out.println("----------------------------ARRAY EN DESORDEN");
      //Se asigna  el tamaño de la matriz a llenar
       int[]lista=new int[tamano];
       
        for (int i = 0; i < lista.length-1; i++) {
            lista[i]=r.nextInt(100);
            System.out.println(lista[i]);
        }
        int[]lista2=lista;
        int[]lista3=lista;
        int[]lista4=lista;
        int temporal=0;
          System.out.println("----------------------------METODO BURBUJA");
           //Se ordena la matriz comparando elemento con toda la matriz
        for(int k=0;k<lista.length-1;k++){
          for(int j=0;j<lista.length-1;j++){
            if(lista[k]<lista[j]){
                temporal=lista[k];
                lista[k]=lista[j];
                lista[j]=temporal;
                
            }
        }
        }
          //Se imprime la matriz ordenada
        for(int l=0;l<lista.length-1;l++){
            System.out.println(lista[l]);
        }
      
        System.out.println("---------------------ORDENAMIENTO QUICKSHORT");
        //METODO DE ORDENAMIENTO BURBUJA
        //Selecciono el pivote
        int pivote=lista2[lista2.length/2];
        //Obtengo el tamaño maximo del array
        int temporal1=lista2.length-1;
        //Variable utilizadas para guardar los valores por derecha y por izquierda
        int derecha=0;
        int izquierda=0;
        //Guarda la posicion cuando se cumple la condicion
        int posicionizquierda=0;
        int posicionDerecha=0;
    
        for(int n=0;n<lista2.length-1;n++)
        {
            //ASIGNA LA POSICION A IZQUIERDA
          if(pivote>lista2[n] && izquierda==0){
              izquierda=lista2[n];
              posicionizquierda=n;
          }
          //ASIGNA A LA POSICION A DERECHA
          if(pivote<lista2[temporal1] && derecha==0){
          derecha=lista2[temporal1];
          posicionDerecha=temporal1;
          }
          if(izquierda!=0 && derecha!=0){
          lista2[posicionizquierda]=izquierda;
          lista2[posicionDerecha]=derecha;
          izquierda=0;
          derecha=0;
          posicionDerecha=0;
          posicionizquierda=0;
          }
        }
        //Primera iteracion con todo el vector
        for(int n=0;n<lista2.length-1;n++)
        {
          if(pivote>lista2[n] && izquierda==0){
              izquierda=lista2[n];
              posicionizquierda=n;
          }
          if(pivote<lista2[temporal1] && derecha==0){
          derecha=lista2[temporal1];
          posicionDerecha=temporal1;
          }
          if(izquierda!=0 && derecha!=0){
          lista2[posicionizquierda]=izquierda;
          lista2[posicionDerecha]=derecha;
          izquierda=0;
          derecha=0;
          posicionDerecha=0;
          posicionizquierda=0;
          }
        }
        //segunda iteracion ordenando izquierda y derecha
        //Selecciono el pivote
         pivote=lista2[(lista2.length/2)/2];
        //Obtengo el tamaño maximo del array
         temporal1=lista2.length-1;
        //Variable utilizadas para guardar los valores por derecha y por izquierda
         derecha=0;
         izquierda=0;
        //Guarda la posicion cuando se cumple la condicion
         posicionizquierda=0;
         posicionDerecha=0;
         //Ordena derecha y izquierda por separado
         for(int o=0;o<(lista2.length-1)/2;o++){
           if(pivote>lista2[o] && izquierda==0){
              izquierda=lista2[o];
              posicionizquierda=o;
          }
           //Asigno valido la izquierda y valido la derecha
          if(pivote<lista2[temporal1] && derecha==0){
          derecha=lista2[temporal1];
          posicionDerecha=temporal1;
          }
          if(izquierda!=0 && derecha!=0){
          lista2[posicionizquierda]=izquierda;
          lista2[posicionDerecha]=derecha;
          izquierda=0;
          derecha=0;
          posicionDerecha=0;
          posicionizquierda=0;
          }
        }
        for (int n = 0; n < lista2.length-1; n++) {
            System.out.println(""+lista2[n]);
        }
        
        
        //ORDENAMIENTO PAINE
        System.out.println("-------------ORDENAMIENTO PEINE");
        //Guarda el tamaño de la longitud del peine
        int extremoDerecha=lista3.length/2;
        //Guarda el numero de ciclos evaluados
        temporal=0;
        //Guarda los valores temporales para ordenar
        int ciclo=0;
        //Recorre hasta que la variable extremoDerecha sea ajusta 2
        do{
             for(int i=0;i<(lista3.length-1)/2;i++){
            if(lista3[i]>lista3[extremoDerecha]){
             ciclo=lista3[i];
             lista3[i]=lista3[extremoDerecha];
             lista3[extremoDerecha]=ciclo;
             extremoDerecha++;
            }
           
        }
            temporal++;
            //Calculo el nuevo valor del peine
            extremoDerecha=(lista3.length/2)-temporal;
        }while(extremoDerecha==2);
        //Imprimo el array ordenado
        for (int i = 0; i < lista3.length-1; i++) {
            System.out.println(""+lista3[i]);
        }
        
        
      
    }
    
}
